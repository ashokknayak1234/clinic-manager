# OpenClinic frontend

OpenClinic is a React, TypeScript, and Vite healthcare-management **frontend demonstration**. It includes a role-specific patient portal, doctor workspace, and administrative workspace. No backend or authentication provider is configured in this project.

## Run locally

```sh
npm install
npm run dev
```

Use any valid email address, a password of at least six characters, and choose a demo workspace on the sign-in page. Patients can also register without a clinic ID using their name, phone number, and email, then sign in with those same details. Patient registrations exist only in browser memory for the current page session and are cleared on refresh. The role picker selects a fictional demo persona; it does not verify identity. The selected persona and route guards are for demonstration and navigation only, not authorization.

## Free Netlify deployment

This project is configured for Netlify. Sign in to Netlify, choose **Add new project** → **Deploy manually**, and upload the generated `dist` folder. To create that folder, run:

```sh
npm install
npm run build
```

Alternatively, connect the project’s Git repository to Netlify; it will use the build command and publish directory in `netlify.toml`. The site will be publicly accessible at its Netlify URL. This is a frontend demonstration only: it has no backend, and its sign-in and data are simulated.

## Demo workflows

- Patient: review sample appointments and records, create an appointment request preview, and view/edit a profile preview.
- Patient access: register without a clinic ID and use the registered name, phone number, and email to sign in during the same browser session.
- Doctor: review a sample schedule, view fictional patient profiles, and toggle sample availability.
- Administrator: view clinic summary data, filter appointments and directories, preview appointment status changes, and add/manage sample providers.
- Changes to appointments and provider data are held in frontend memory for the current page session. They are not persistent, transmitted, booked, or confirmed.
- All names, contact details, appointments, records, and metrics are fictional demonstration data. Do not enter real patient information or credentials.

## Frontend integration seams

- `src/services/clinicApi.ts` contains the mock service operations to replace with the backend client's authenticated API calls.
- `src/auth/AuthContext.tsx` currently calls the explicitly named `demoSignIn` flow. Replace it with the backend authentication flow and use the server-verified role; never trust the UI role picker for privileges.
- `src/types.ts` contains frontend view models. Align them with the backend API contract when available.
- `src/data/demoData.ts` contains fictional data for development and can be replaced by service responses.
- React Router guards and role-specific navigation improve the frontend experience only. The backend must authenticate every request and enforce authorization, patient assignment, and record access.

## Checks

```sh
npm run build
npm run lint
```
