import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider } from './auth/AuthContext'
import { useAuth } from './auth/useAuth'
import { ClinicLayout } from './components/ClinicLayout'
import './App.css'
import { LoginPage } from './pages/LoginPage'
import { RegistrationPage } from './pages/RegistrationPage'
import {
  AppointmentsPage,
  DashboardPage,
  ManagementPage,
  NotFoundPage,
  ProfilePage,
  RecordsPage,
} from './pages/WorkspacePages'
import type { Role } from './types'

function DashboardRedirect() {
  const { user } = useAuth()
  return <Navigate to={`/${user?.role ?? 'login'}`} replace />
}

function ProtectedRoute({ allowedRoles }: { allowedRoles?: Role[] }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to={`/${user.role}`} replace />
  return <ClinicLayout />
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegistrationPage />} />
      <Route element={<ProtectedRoute />}>
        <Route path="/" element={<DashboardRedirect />} />
        <Route path="/patient" element={<DashboardPage role="patient" />} />
        <Route path="/doctor" element={<DashboardPage role="doctor" />} />
        <Route path="/admin" element={<DashboardPage role="admin" />} />
        <Route path="/appointments" element={<AppointmentsPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/records" element={<RecordsPage />} />
        <Route path="/patients" element={<ManagementPage section="patients" allowedRoles={['doctor', 'admin']} />} />
        <Route path="/doctors" element={<ManagementPage section="doctors" allowedRoles={['admin']} />} />
        <Route path="/services" element={<ManagementPage section="services" allowedRoles={['admin']} />} />
        <Route path="/schedule" element={<ManagementPage section="schedule" allowedRoles={['doctor']} />} />
        <Route path="/reports" element={<ManagementPage section="reports" allowedRoles={['admin']} />} />
        <Route path="/settings" element={<ManagementPage section="settings" allowedRoles={['admin']} />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  )
}
