import { useMemo, useState, type ReactNode } from 'react'
import { clinicApi } from '../services/clinicApi'
import type { AuthUser, PatientRegistration, Role } from '../types'
import { AuthContext } from './contextStore'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [error, setError] = useState('')

  async function signIn(email: string, password: string, role: Role) {
    setError('')
    if (password.trim().length < 6) {
      setError('Enter a password with at least 6 characters.')
      return false
    }
    try {
      const demoUser = await clinicApi.demoSignIn(email, role)
      setUser(demoUser)
      return true
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Demo sign-in failed. Please try again.')
      return false
    }
  }

  async function signInPatient(name: string, phone: string, email: string) {
    setError('')
    try {
      const patient = await clinicApi.signInPatient(name, phone, email)
      setUser(patient)
      return true
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Patient sign-in failed. Please try again.')
      return false
    }
  }

  async function registerPatient(input: PatientRegistration) {
    setError('')
    try {
      const patient = await clinicApi.registerPatient(input)
      setUser(patient)
      return true
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Registration failed. Please try again.')
      return false
    }
  }

  const value = useMemo(() => ({
    user,
    signIn,
    signInPatient,
    registerPatient,
    signOut: () => setUser(null),
    error,
    clearError: () => setError(''),
  }), [user, error])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
