import { createContext } from 'react'
import type { AuthUser, PatientRegistration, Role } from '../types'

type AuthContextValue = {
  user: AuthUser | null
  signIn: (email: string, password: string, role: Role) => Promise<boolean>
  signInPatient: (name: string, phone: string, email: string) => Promise<boolean>
  registerPatient: (input: PatientRegistration) => Promise<boolean>
  signOut: () => void
  error: string
  clearError: () => void
}

export const AuthContext = createContext<AuthContextValue | null>(null)
