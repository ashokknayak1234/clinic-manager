import { useState, type FormEvent } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import {
  Activity, BarChart3, Bell, CalendarDays, FileText, HeartPulse, LayoutDashboard,
  LogOut, Menu, Search, Settings, Stethoscope, UserRound, Users, X,
} from 'lucide-react'
import { useAuth } from '../auth/useAuth'

const navigation = {
  patient: [
    { label: 'Dashboard', path: '/patient', icon: LayoutDashboard },
    { label: 'Appointments', path: '/appointments', icon: CalendarDays },
    { label: 'Medical records', path: '/records', icon: FileText },
    { label: 'My profile', path: '/profile', icon: UserRound },
  ],
  doctor: [
    { label: 'Dashboard', path: '/doctor', icon: LayoutDashboard },
    { label: 'Appointments', path: '/appointments', icon: CalendarDays },
    { label: 'Patients', path: '/patients', icon: Users },
    { label: 'My schedule', path: '/schedule', icon: Stethoscope },
    { label: 'My profile', path: '/profile', icon: UserRound },
  ],
  admin: [
    { label: 'Dashboard', path: '/admin', icon: LayoutDashboard },
    { label: 'Appointments', path: '/appointments', icon: CalendarDays },
    { label: 'Patients', path: '/patients', icon: Users },
    { label: 'Doctors', path: '/doctors', icon: Stethoscope },
    { label: 'Services', path: '/services', icon: Activity },
    { label: 'Reports', path: '/reports', icon: BarChart3 },
    { label: 'Settings', path: '/settings', icon: Settings },
    { label: 'My profile', path: '/profile', icon: UserRound },
  ],
}

export function ClinicLayout() {
  const { user, signOut } = useAuth()
  const [menuOpen, setMenuOpen] = useState(false)
  const [search, setSearch] = useState('')
  const navigate = useNavigate()
  if (!user) return null

  function submitSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    navigate(`/appointments?search=${encodeURIComponent(search.trim())}`)
    setMenuOpen(false)
  }

  return (
    <div className="clinic-app">
      {menuOpen && <button className="sidebar-scrim" aria-label="Close navigation" onClick={() => setMenuOpen(false)} />}
      <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
        <NavLink to={`/${user.role}`} className="brand" onClick={() => setMenuOpen(false)}>
          <span className="brand-mark"><HeartPulse size={21} /></span>
          <span className="brand-name">OpenClinic<small>CARE MANAGEMENT</small></span>
        </NavLink>
        <div className="sidebar-label">WORKSPACE</div>
        <nav className="side-nav" aria-label={`${user.role} navigation`}>
          {navigation[user.role].map(({ label, path, icon: Icon }) => (
            <NavLink key={path} to={path} onClick={() => setMenuOpen(false)} className={({ isActive }) => `side-link${isActive ? ' active' : ''}`}>
              <Icon size={18} strokeWidth={1.8} /><span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-note">
          <span className="demo-pill"><span /> DEMO WORKSPACE</span>
          <p>Sample data only. No information is sent to a clinic or backend.</p>
        </div>
        <button className="sidebar-account" onClick={() => navigate('/profile')}>
          <span className="avatar">{user.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span>
          <span className="account-copy"><strong>{user.name}</strong><small>{user.title ?? user.role}</small></span>
        </button>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <button className="icon-button mobile-menu-toggle" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen((open) => !open)}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <form className="global-search" onSubmit={submitSearch} role="search">
            <Search size={17} aria-hidden="true" />
            <input aria-label="Search appointments" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search appointments..." />
            {search && <button type="button" aria-label="Clear search" onClick={() => setSearch('')}>×</button>}
          </form>
          <div className="topbar-actions">
            <button className="icon-button notification-button" aria-label="Notifications: demo mode" title="Notifications are not connected in demo mode" onClick={() => window.alert('There are no live notifications in this demo. Connect the backend to enable clinic alerts.')}><Bell size={19} /><span /></button>
            <div className="topbar-divider" />
            <button className="topbar-user" onClick={() => navigate('/profile')} aria-label="Open profile">
              <span className="avatar avatar-small">{user.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span>
              <span><strong>{user.name}</strong><small>{user.role === 'admin' ? 'Administrator' : user.role === 'doctor' ? 'Care team' : 'Patient'}</small></span>
            </button>
            <button className="icon-button logout-button" aria-label="Sign out" title="Sign out" onClick={() => { signOut(); navigate('/login') }}><LogOut size={18} /></button>
          </div>
        </header>
        <main className="page-content"><Outlet /></main>
        <footer className="workspace-footer">OpenClinic demo workspace <span>·</span> Sample data only — connect a backend for live clinic workflows.</footer>
      </div>
    </div>
  )
}
