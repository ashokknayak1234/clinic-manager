import type { Appointment, Doctor, Patient } from '../types'

export const services = [
  'General Consultation',
  'Heart Health',
  'Health Checkups',
  'Family Medicine',
  'Mental Wellness',
  'Eye Care',
  'Orthopedics',
  'Dermatology',
]

export const demoDoctors: Doctor[] = [
  { id: 'doc-1', name: 'Dr. Ananya Mehta', specialty: 'General Physician', email: 'ananya@openclinic.demo', status: 'Active' },
  { id: 'doc-2', name: 'Dr. Rahul Kumar', specialty: 'Cardiologist', email: 'rahul@openclinic.demo', status: 'Active' },
  { id: 'doc-3', name: 'Dr. Sneha Patel', specialty: 'Dermatologist', email: 'sneha@openclinic.demo', status: 'Active' },
  { id: 'doc-4', name: 'Dr. Neel Verma', specialty: 'Family Medicine', email: 'neel@openclinic.demo', status: 'On leave' },
  { id: 'doc-5', name: 'Dr. Isha Shah', specialty: 'Mental Wellness', email: 'isha@openclinic.demo', status: 'Active' },
  { id: 'doc-6', name: 'Dr. Ayaan Rao', specialty: 'Orthopedics', email: 'ayaan@openclinic.demo', status: 'Active' },
]

export const demoPatients: Patient[] = [
  { id: 'pat-1', name: 'Aarav Shah', email: 'aarav@openclinic.demo', phone: '+91 90000 01001', lastVisit: '2026-10-08', status: 'Follow-up' },
  { id: 'pat-2', name: 'Mira Joshi', email: 'mira@openclinic.demo', phone: '+91 90000 01002', lastVisit: '2026-10-05', status: 'Active' },
  { id: 'pat-3', name: 'Kabir Nair', email: 'kabir@openclinic.demo', phone: '+91 90000 01003', lastVisit: '2026-09-29', status: 'Active' },
  { id: 'pat-4', name: 'Diya Menon', email: 'diya@openclinic.demo', phone: '+91 90000 01004', lastVisit: '2026-09-22', status: 'Follow-up' },
]

const today = new Date()
const dateOffset = (days: number) => {
  const date = new Date(today)
  date.setDate(date.getDate() + days)
  return date.toISOString().slice(0, 10)
}

export const demoAppointments: Appointment[] = [
  { id: 'apt-1', patientId: 'pat-1', patientName: 'Aarav Shah', doctorId: 'doc-1', doctorName: 'Dr. Ananya Mehta', service: 'General Consultation', date: dateOffset(0), time: '09:00', status: 'Confirmed' },
  { id: 'apt-2', patientId: 'pat-2', patientName: 'Mira Joshi', doctorId: 'doc-2', doctorName: 'Dr. Rahul Kumar', service: 'Heart Health', date: dateOffset(0), time: '10:30', status: 'Requested' },
  { id: 'apt-3', patientId: 'pat-3', patientName: 'Kabir Nair', doctorId: 'doc-1', doctorName: 'Dr. Ananya Mehta', service: 'Health Checkups', date: dateOffset(1), time: '11:00', status: 'Confirmed' },
  { id: 'apt-4', patientId: 'pat-4', patientName: 'Diya Menon', doctorId: 'doc-3', doctorName: 'Dr. Sneha Patel', service: 'Dermatology', date: dateOffset(2), time: '14:00', status: 'Confirmed' },
  { id: 'apt-5', patientId: 'pat-1', patientName: 'Aarav Shah', doctorId: 'doc-1', doctorName: 'Dr. Ananya Mehta', service: 'General Consultation', date: dateOffset(-7), time: '09:30', status: 'Completed' },
]

export const demoRecords = [
  { date: '2026-10-08', type: 'Visit summary', detail: 'General consultation', provider: 'Dr. Ananya Mehta' },
  { date: '2026-09-18', type: 'Prescription', detail: 'Sample prescription · demo only', provider: 'Dr. Rahul Kumar' },
  { date: '2026-07-12', type: 'Lab result', detail: 'Sample report · demo only', provider: 'OpenClinic Demo' },
]
