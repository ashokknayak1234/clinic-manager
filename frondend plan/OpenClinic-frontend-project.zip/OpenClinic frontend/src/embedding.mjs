
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

const words = process.argv.slice(2);

if (words.length === 0) {
  console.error('Usage: node src/embedding.mjs "your words"');
  process.exit(1);
}

try {
  const result = await ai.models.embedContent({
    model: "gemini-embedding-001",
    contents: words,
  });

  console.log(
    JSON.stringify(
      result.embeddings.map(item => item.values)
    )
  );
} catch (error) {
  console.error("Error:", error.message);
  process.exitCode = 1;
}
