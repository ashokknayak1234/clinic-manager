import { useState, type FormEvent } from 'react'
import { Activity, ArrowRight, CalendarDays, Eye, EyeOff, HeartPulse, LockKeyhole, Mail, Phone, ShieldCheck, Stethoscope, UserRound } from 'lucide-react'
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../auth/useAuth'
import type { Role } from '../types'

const roles: { id: Role; label: string; description: string }[] = [
  { id: 'patient', label: 'Patient', description: 'Your care and appointments' },
  { id: 'doctor', label: 'Doctor', description: 'Clinical workspace' },
  { id: 'admin', label: 'Administrator', description: 'Clinic operations' },
]
const currentYear = new Date().getFullYear()

export function LoginPage() {
  const { user, signIn, signInPatient, error, clearError } = useAuth()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [role, setRole] = useState<Role>('patient')
  const [patientAccess, setPatientAccess] = useState(searchParams.get('mode') === 'patient')
  const [patientName, setPatientName] = useState('')
  const [patientPhone, setPatientPhone] = useState('')
  const [patientEmail, setPatientEmail] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [remember, setRemember] = useState(false)
  const [forgotMessage, setForgotMessage] = useState('')
  const [busy, setBusy] = useState(false)

  if (user) return <Navigate to={`/${user.role}`} replace />

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    clearError()
    setForgotMessage('')
    setBusy(true)
    const success = await signIn(email, password, role)
    setBusy(false)
    if (success) navigate(`/${role}`)
  }

  async function submitPatient(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    clearError()
    setBusy(true)
    const success = await signInPatient(patientName, patientPhone, patientEmail)
    setBusy(false)
    if (success) navigate('/patient')
  }

  function changeAccessMode(usePatientAccess: boolean) {
    clearError()
    setPatientAccess(usePatientAccess)
  }

  return (
    <main className="login-page">
      <section className="login-panel">
        <a className="brand login-brand" href="/login">
          <span className="brand-mark"><HeartPulse size={22} /></span>
          <span className="brand-name">OpenClinic<small>CARE MANAGEMENT</small></span>
        </a>
        <div className="login-form-wrap">
          <div className="login-heading">
            <span className="eyebrow">{patientAccess ? 'PATIENT ACCESS' : 'WELCOME TO YOUR WORKSPACE'}</span>
            <h1>{patientAccess ? 'Sign in without an ID' : 'Sign in to OpenClinic'}</h1>
            <p>{patientAccess ? 'Use the name, phone number, and email you registered with.' : 'Access your healthcare workspace with your account.'}</p>
          </div>
          <div className="demo-alert" role="note">
            <span className="demo-alert-icon"><Activity size={17} /></span>
            <p><strong>Demo mode</strong> — no backend is connected. {patientAccess ? 'Patient accounts are kept in memory for this browser session only.' : 'Use any valid email and a password of 6+ characters.'} Do not enter real patient information.</p>
          </div>
          <form onSubmit={patientAccess ? submitPatient : submit}>
            {patientAccess ? (
              <>
                <label className="field-label" htmlFor="patient-name">Full name</label>
                <div className="input-with-icon"><UserRound size={17} aria-hidden="true" /><input id="patient-name" type="text" autoComplete="name" required value={patientName} onChange={(event) => setPatientName(event.target.value)} placeholder="Your registered name" /></div>
                <label className="field-label" htmlFor="patient-phone">Phone number</label>
                <div className="input-with-icon"><Phone size={17} aria-hidden="true" /><input id="patient-phone" type="tel" autoComplete="tel" required value={patientPhone} onChange={(event) => setPatientPhone(event.target.value)} placeholder="Your registered phone number" /></div>
                <label className="field-label" htmlFor="patient-email">Gmail or email address</label>
                <div className="input-with-icon"><Mail size={17} aria-hidden="true" /><input id="patient-email" type="email" autoComplete="email" required value={patientEmail} onChange={(event) => setPatientEmail(event.target.value)} placeholder="you@gmail.com" /></div>
              </>
            ) : (
              <>
                <fieldset className="role-fieldset">
              <legend>Choose a demo workspace</legend>
              <div className="role-options">
                {roles.map((item) => (
                  <button key={item.id} className={`role-choice ${role === item.id ? 'selected' : ''}`} type="button" onClick={() => setRole(item.id)} aria-pressed={role === item.id}>
                    <span className="role-choice-icon">{item.id === 'patient' ? <HeartPulse size={18} /> : item.id === 'doctor' ? <Stethoscope size={18} /> : <ShieldCheck size={18} />}</span>
                    <span><strong>{item.label}</strong><small>{item.description}</small></span>
                    <span className="role-radio" />
                  </button>
                ))}
              </div>
              <p className="role-warning">Role selection only chooses a fictional demo persona. It does not verify identity or grant real permissions.</p>
                </fieldset>

                <label className="field-label" htmlFor="email">Email address</label>
                <div className="input-with-icon"><Mail size={17} aria-hidden="true" /><input id="email" type="email" autoComplete="username" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" /></div>
                <label className="field-label password-label" htmlFor="password">Password</label>
                <div className="input-with-icon"><LockKeyhole size={17} aria-hidden="true" /><input id="password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" minLength={6} required value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter any 6+ characters" /><button type="button" className="password-toggle" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword((shown) => !shown)}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>
                <div className="login-options"><label className="checkbox-label"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} /> Remember me</label><button className="text-button" type="button" onClick={() => setForgotMessage('Password reset is unavailable in demo mode because there is no authentication service connected.')}>Forgot password?</button></div>
              </>
            )}
            {(error || forgotMessage) && <p className="form-message error-message" role="alert">{error || forgotMessage}</p>}
            <button className="button button-primary login-submit" type="submit" disabled={busy}>{busy ? 'Signing in...' : patientAccess ? 'Sign in as patient' : 'Sign in to demo'} <ArrowRight size={17} /></button>
          </form>
          <div className="auth-links">
            {patientAccess ? (
              <>
                <button className="text-button" type="button" onClick={() => changeAccessMode(false)}>Use demo workspace sign-in</button>
                <Link className="button button-secondary auth-register-button" to="/register">Create patient account</Link>
              </>
            ) : (
              <>
                <button className="text-button" type="button" onClick={() => changeAccessMode(true)}>Patient sign-in without an ID</button>
                <Link className="button button-secondary auth-register-button" to="/register">Register as a patient</Link>
              </>
            )}
          </div>
          <p className="login-privacy"><LockKeyhole size={14} /> Demo only · Do not enter real credentials or patient information.</p>
        </div>
        <div className="login-bottom">© {currentYear} OpenClinic <span>·</span> Frontend demonstration</div>
      </section>
      <aside className="login-visual">
        <div className="visual-top"><span className="visual-mark"><HeartPulse size={23} /></span><span>Care teams, connected.</span></div>
        <div className="visual-center">
          <div className="visual-icon"><HeartPulse size={65} strokeWidth={1.2} /></div>
          <span className="visual-cross">+</span>
          <div className="visual-card visual-card-one"><span className="mini-icon"><CalendarDays size={19} /></span><span><strong>Care made clear</strong><small>A connected clinic workspace</small></span><span className="tiny-check">✓</span></div>
          <div className="visual-card visual-card-two"><span className="mini-icon"><Activity size={19} /></span><span><strong>People first</strong><small>One step at a time</small></span></div>
        </div>
        <div className="visual-caption"><span className="caption-line" /><div><strong>One place for better care.</strong><p>Appointments, people, and clinic workflows in a single workspace.</p></div></div>
        <span className="visual-disclaimer">Illustrative visual · Not a live clinical system</span>
      </aside>
    </main>
  )
}
