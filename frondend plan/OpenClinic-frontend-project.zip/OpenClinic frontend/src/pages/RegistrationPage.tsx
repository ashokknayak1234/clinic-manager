import { useState, type FormEvent } from 'react'
import { Activity, ArrowRight, CalendarDays, HeartPulse, LockKeyhole, Mail, Phone, UserRound } from 'lucide-react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth/useAuth'

const currentYear = new Date().getFullYear()

export function RegistrationPage() {
  const { user, registerPatient, error, clearError } = useAuth()
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [busy, setBusy] = useState(false)

  if (user) return <Navigate to={`/${user.role}`} replace />

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    clearError()
    setBusy(true)
    const success = await registerPatient({ name, phone, email })
    setBusy(false)
    if (success) navigate('/patient')
  }

  return (
    <main className="login-page">
      <section className="login-panel">
        <Link className="brand login-brand" to="/login">
          <span className="brand-mark"><HeartPulse size={22} /></span>
          <span className="brand-name">OpenClinic<small>CARE MANAGEMENT</small></span>
        </Link>
        <div className="login-form-wrap">
          <div className="login-heading">
            <span className="eyebrow">PATIENT REGISTRATION</span>
            <h1>Create your patient account</h1>
            <p>No clinic ID is needed. Register with your name, phone, and email.</p>
          </div>
          <div className="demo-alert" role="note">
            <span className="demo-alert-icon"><Activity size={17} /></span>
            <p><strong>Demo mode</strong> — this is a frontend demonstration. Account details stay in memory for this browser session and are cleared when the page is refreshed. Do not enter real patient information.</p>
          </div>
          <form onSubmit={submit}>
            <label className="field-label" htmlFor="register-name">Full name</label>
            <div className="input-with-icon"><UserRound size={17} aria-hidden="true" /><input id="register-name" type="text" autoComplete="name" required maxLength={100} value={name} onChange={(event) => setName(event.target.value)} placeholder="Enter your full name" /></div>
            <label className="field-label" htmlFor="register-phone">Phone number</label>
            <div className="input-with-icon"><Phone size={17} aria-hidden="true" /><input id="register-phone" type="tel" autoComplete="tel" required value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Enter your phone number" /></div>
            <label className="field-label" htmlFor="register-email">Gmail or email address</label>
            <div className="input-with-icon"><Mail size={17} aria-hidden="true" /><input id="register-email" type="email" autoComplete="email" required maxLength={254} value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@gmail.com" /></div>
            {error && <p className="form-message error-message" role="alert">{error}</p>}
            <button className="button button-primary login-submit registration-submit" type="submit" disabled={busy}>{busy ? 'Creating account...' : 'Register and continue'} <ArrowRight size={17} /></button>
          </form>
          <div className="auth-links auth-links-centered"><span>Already registered? <Link to="/login?mode=patient">Sign in with your details</Link></span></div>
          <p className="login-privacy"><LockKeyhole size={14} /> Demo only · No real clinic account or patient ID is created.</p>
        </div>
        <div className="login-bottom">© {currentYear} OpenClinic <span>·</span> Frontend demonstration</div>
      </section>
      <aside className="login-visual">
        <div className="visual-top"><span className="visual-mark"><HeartPulse size={23} /></span><span>Care teams, connected.</span></div>
        <div className="visual-center">
          <div className="visual-icon"><HeartPulse size={65} strokeWidth={1.2} /></div>
          <span className="visual-cross">+</span>
          <div className="visual-card visual-card-one"><span className="mini-icon"><CalendarDays size={19} /></span><span><strong>Care made clear</strong><small>A connected clinic workspace</small></span><span className="tiny-check">✓</span></div>
          <div className="visual-card visual-card-two"><span className="mini-icon"><Activity size={19} /></span><span><strong>People first</strong><small>One step at a time</small></span></div>
        </div>
        <div className="visual-caption"><span className="caption-line" /><div><strong>One place for better care.</strong><p>Appointments, people, and clinic workflows in a single workspace.</p></div></div>
        <span className="visual-disclaimer">Illustrative visual · Not a live clinical system</span>
      </aside>
    </main>
  )
}
