import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react'
import { Link, Navigate, useSearchParams } from 'react-router-dom'
import {
  Activity, ArrowDown, ArrowRight, ArrowUp, CalendarDays, Check, CheckCircle2,
  ChevronDown, Clock3, FileText, Filter, Pencil, Plus, Search, Stethoscope, Users, X,
} from 'lucide-react'
import { useAuth } from '../auth/useAuth'
import { demoRecords, demoPatients, services } from '../data/demoData'
import { clinicApi } from '../services/clinicApi'
import type { Appointment, AppointmentStatus, Doctor, Patient, Role } from '../types'

const prettyDate = (value: string) => new Date(`${value}T00:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })
const today = new Date()
const todayIso = today.toISOString().slice(0, 10)
const longDate = new Intl.DateTimeFormat(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).format(today)

function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow?: string; title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="page-heading"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{action}</div>
}

function StatCard({ label, value, detail, icon: Icon, tone = 'teal' }: { label: string; value: string | number; detail: string; icon: typeof Users; tone?: string }) {
  return <article className="stat-card"><span className={`stat-icon ${tone}`}><Icon size={20} /></span><span className="stat-label">{label}</span><strong>{value}</strong><small>{detail}</small></article>
}

function StatusBadge({ status }: { status: AppointmentStatus | Patient['status'] | Doctor['status'] }) {
  return <span className={`status-badge status-${status.toLowerCase().replaceAll(' ', '-')}`}><span />{status}</span>
}

function EmptyState({ title, detail, action }: { title: string; detail: string; action?: ReactNode }) {
  return <div className="empty-state"><span className="empty-icon"><CalendarDays size={22} /></span><h3>{title}</h3><p>{detail}</p>{action}</div>
}

export function DashboardPage({ role }: { role: Role }) {
  const { user } = useAuth()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [loadError, setLoadError] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    clinicApi.getAppointments().then((items) => { if (active) setAppointments(items) }).catch(() => { if (active) setLoadError('Could not load sample appointments. Please refresh the page.') }).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])

  if (!user || user.role !== role) return <Navigate to={user ? `/${user.role}` : '/login'} replace />
  const visible = appointments.filter((item) => role === 'admin' || (role === 'patient' ? item.patientId === user.id : item.doctorId === user.id))
  const upcoming = visible.filter((item) => item.date >= todayIso && item.status !== 'Cancelled').sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))
  const todayCount = visible.filter((item) => item.date === todayIso).length
  const greeting = role === 'patient' ? `Welcome back, ${user.name.split(' ')[0]}` : role === 'doctor' ? `Good morning, ${user.name}` : 'Clinic overview'

  return (
    <div className="page-stack">
      <PageHeading eyebrow={longDate.toUpperCase()} title={greeting} subtitle={role === 'patient' ? 'Here is your care at a glance.' : role === 'doctor' ? 'Your care team workspace for today.' : 'Monitor clinic activity and manage day-to-day operations.'} action={role === 'patient' ? <Link className="button button-primary" to="/appointments?new=1"><Plus size={17} /> Request appointment</Link> : undefined} />
      <div className="demo-banner"><Activity size={17} /><span><strong>Demonstration workspace</strong> All people, appointments, and clinical information shown are fictional sample data.</span></div>
      {loadError && <p className="form-message error-message" role="alert">{loadError}</p>}

      {role === 'patient' ? <PatientDashboard appointments={visible} upcoming={upcoming} loading={loading} /> : (
        <>
          <div className="stats-grid">
            {role === 'admin' ? <>
              <StatCard label="Appointments today" value={todayCount} detail="Across all providers · sample data" icon={CalendarDays} />
              <StatCard label="Registered patients" value={demoPatients.length} detail="Demo directory" icon={Users} tone="blue" />
              <StatCard label="Active doctors" value="5" detail="1 provider on leave · demo" icon={Stethoscope} tone="green" />
              <StatCard label="Pending requests" value={appointments.filter((item) => item.status === 'Requested').length} detail="Review in appointments" icon={Clock3} tone="amber" />
            </> : <>
              <StatCard label="Today's appointments" value={todayCount} detail={longDate} icon={CalendarDays} />
              <StatCard label="Upcoming visits" value={upcoming.length} detail="Scheduled in your workspace" icon={Clock3} tone="blue" />
              <StatCard label="Assigned patients" value={demoPatients.length} detail="Fictional sample list" icon={Users} tone="green" />
              <StatCard label="Availability" value="Available" detail="Set by you in demo schedule" icon={CheckCircle2} tone="amber" />
            </>}
          </div>
          <div className="content-grid dashboard-grid">
            <section className="surface-card">
              <div className="card-heading"><div><h2>{role === 'doctor' ? "Today's schedule" : 'Appointment activity'}</h2><p>{role === 'doctor' ? 'Your next visits and requests.' : 'Recent clinic appointments across the team.'}</p></div><Link className="inline-link" to="/appointments">View all <ArrowRight size={15} /></Link></div>
              <AppointmentsTable appointments={(role === 'doctor' ? visible : appointments).slice(0, 5)} loading={loading} compact />
            </section>
            <aside className="surface-card quick-panel">
              <div className="card-heading"><div><h2>Quick actions</h2><p>Common workspace tasks</p></div></div>
              {(role === 'doctor' ? [
                { label: 'Review appointment requests', to: '/appointments', icon: CalendarDays },
                { label: 'Open patient directory', to: '/patients', icon: Users },
                { label: 'Manage availability', to: '/schedule', icon: Clock3 },
              ] : [
                { label: 'Manage appointments', to: '/appointments', icon: CalendarDays },
                { label: 'View patient directory', to: '/patients', icon: Users },
                { label: 'Manage care team', to: '/doctors', icon: Stethoscope },
              ]).map(({ label, to, icon: Icon }) => <Link key={to} className="quick-link" to={to}><span><Icon size={18} /></span>{label}<ArrowRight size={15} /></Link>)}
              <p className="panel-footnote">Changes in this demonstration are temporary and visible only during this session.</p>
            </aside>
          </div>
        </>
      )}
    </div>
  )
}

function PatientDashboard({ appointments, upcoming, loading }: { appointments: Appointment[]; upcoming: Appointment[]; loading: boolean }) {
  const next = upcoming[0]
  return <>
    <div className="stats-grid">
      <StatCard label="Upcoming appointments" value={upcoming.length} detail="Your care plan" icon={CalendarDays} />
      <StatCard label="Completed visits" value={appointments.filter((item) => item.status === 'Completed').length} detail="History in this demo" icon={CheckCircle2} tone="green" />
      <StatCard label="Care team" value="6" detail="Available sample providers" icon={Stethoscope} tone="blue" />
      <StatCard label="Medical records" value={demoRecords.length} detail="Fictional sample entries" icon={FileText} tone="amber" />
    </div>
    <div className="content-grid patient-dashboard-grid">
      <section className="surface-card next-visit-card">
        <div className="card-heading"><div><h2>Your next visit</h2><p>Upcoming appointment overview</p></div><CalendarDays size={20} className="heading-icon" /></div>
        {loading ? <div className="loading-state">Loading your sample appointments...</div> : next ? <div className="next-visit">
          <div className="visit-date"><span>{new Date(`${next.date}T00:00:00`).toLocaleDateString(undefined, { month: 'short' }).toUpperCase()}</span><strong>{new Date(`${next.date}T00:00:00`).getDate()}</strong></div>
          <div className="visit-details"><StatusBadge status={next.status} /><h3>{next.service}</h3><p>{next.doctorName} <span>·</span> {next.time}</p></div>
          <Link className="inline-link" to="/appointments">Details <ArrowRight size={15} /></Link>
        </div> : <EmptyState title="No upcoming appointments" detail="When you request a visit, it will appear here." action={<Link className="button button-primary button-small" to="/appointments?new=1"><Plus size={16} /> Request a visit</Link>} />}
        {next && <p className="panel-footnote">Demo status only. Appointment requests require confirmation from a connected clinic system.</p>}
      </section>
      <section className="surface-card care-card">
        <div className="care-card-art"><HeartPulseIcon /></div><div><span className="eyebrow">YOUR CARE, YOUR PACE</span><h2>Make time for your health.</h2><p>Browse sample clinic services and create a request preview in demo mode.</p><Link className="inline-link" to="/appointments?new=1">Request an appointment <ArrowRight size={15} /></Link></div>
      </section>
      <section className="surface-card">
        <div className="card-heading"><div><h2>Recent activity</h2><p>Your past and requested visits</p></div><Link className="inline-link" to="/appointments">Appointment history <ArrowRight size={15} /></Link></div>
        <AppointmentsTable appointments={appointments.slice(0, 4)} loading={loading} compact />
      </section>
      <section className="surface-card records-shortcut">
        <div className="card-heading"><div><h2>Medical records</h2><p>Sample records for interface preview only</p></div><FileText size={20} className="heading-icon" /></div>
        {demoRecords.slice(0, 2).map((record) => <div className="record-row" key={record.date}><span className="record-icon"><FileText size={17} /></span><span><strong>{record.type}</strong><small>{record.detail} · {prettyDate(record.date)}</small></span><ArrowRight size={15} /></div>)}
        <Link className="inline-link records-link" to="/records">View all records <ArrowRight size={15} /></Link>
      </section>
    </div>
  </>
}

function HeartPulseIcon() {
  return <Activity size={35} strokeWidth={1.5} />
}

export function AppointmentsPage() {
  const { user } = useAuth()
  const [searchParams, setSearchParams] = useSearchParams()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [serviceChoices, setServiceChoices] = useState<string[]>(services)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const search = searchParams.get('search') ?? ''
  const [status, setStatus] = useState('All statuses')
  const [sortAscending, setSortAscending] = useState(true)
  const [formOpen, setFormOpen] = useState(searchParams.get('new') === '1')
  const [success, setSuccess] = useState('')

  useEffect(() => {
    let active = true
    Promise.all([clinicApi.getAppointments(), clinicApi.getDoctors(), clinicApi.getServices()]).then(([rows, providers, catalog]) => {
      if (active) { setAppointments(rows); setDoctors(providers); setServiceChoices(catalog) }
    }).catch(() => { if (active) setError('Could not load the sample appointment list. Please try again.') }).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])
  if (!user) return null
  const currentUser = user
  const visibleByRole = appointments.filter((item) => currentUser.role === 'admin' || (currentUser.role === 'patient' ? item.patientId === currentUser.id : item.doctorId === currentUser.id))
  const filtered = visibleByRole.filter((item) => {
    const text = `${item.patientName} ${item.doctorName} ${item.service} ${item.status}`.toLowerCase()
    return text.includes(search.toLowerCase()) && (status === 'All statuses' || item.status === status)
  }).sort((a, b) => (sortAscending ? 1 : -1) * `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))

  async function changeStatus(id: string, nextStatus: AppointmentStatus) {
    if (nextStatus === 'Cancelled' && !window.confirm('Cancel this sample appointment? This only changes the demo view.')) return
      try {
        await clinicApi.updateAppointmentStatus(id, nextStatus)
        setAppointments(await clinicApi.getAppointments())
        setSuccess('Appointment status updated in this demo session.')
        setError('')
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : 'Could not update this appointment. Please try again.')
      }
    }

  async function createAppointment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (currentUser.role !== 'patient') return
    const formElement = event.currentTarget
    const form = new FormData(formElement)
    const doctor = doctors.find((item) => item.id === String(form.get('doctorId')))
    if (!doctor) { setError('Choose an available doctor.'); return }
    try {
      const created = await clinicApi.createAppointment({
        patientId: currentUser.id, patientName: currentUser.name, doctorId: doctor.id, doctorName: doctor.name,
        service: String(form.get('service')), date: String(form.get('date')), time: String(form.get('time')),
      })
      formElement.reset()
      setAppointments((items) => [created, ...items])
      setFormOpen(false)
      setSearchParams({})
      setSuccess('Request preview created. It has not been sent to a clinic or confirmed.')
      setError('')
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not create the request preview. Please try again.')
    }
  }

  return <div className="page-stack">
    <PageHeading eyebrow="CARE WORKFLOW" title="Appointments" subtitle={user.role === 'patient' ? 'Review your appointment requests and visit history.' : user.role === 'doctor' ? 'Review your schedule and appointment requests.' : 'Review and manage clinic appointment activity.'} action={user.role === 'patient' ? <button className="button button-primary" onClick={() => setFormOpen(true)}><Plus size={17} /> Request appointment</button> : undefined} />
    <p className="demo-banner"><Activity size={17} /><span><strong>Demo appointments</strong> Status updates and new requests are simulated in this session. Nothing is booked or transmitted.</span></p>
    {success && <div className="form-message success-message" role="status"><Check size={16} />{success}<button onClick={() => setSuccess('')} aria-label="Dismiss message"><X size={15} /></button></div>}
    {error && <p className="form-message error-message" role="alert">{error}</p>}
    <section className="surface-card table-card">
      <div className="table-toolbar">
        <div className="table-toolbar-title"><h2>{user.role === 'patient' ? 'Your appointments' : 'Appointment list'}</h2><span>{filtered.length} records</span></div>
        <div className="table-filters">
          <label className="table-search"><Search size={16} /><input aria-label="Filter appointments" value={search} onChange={(event) => setSearchParams(event.target.value ? { search: event.target.value } : {})} placeholder="Search appointments" /></label>
          <label className="select-filter"><Filter size={15} /><select aria-label="Filter by status" value={status} onChange={(event) => setStatus(event.target.value)}>{['All statuses', 'Requested', 'Confirmed', 'Completed', 'Cancelled'].map((value) => <option key={value}>{value}</option>)}</select><ChevronDown size={14} /></label>
        </div>
      </div>
      <AppointmentsTable appointments={filtered} loading={loading} showActions={currentUser.role !== 'patient'} onStatusChange={changeStatus} onSort={() => setSortAscending((value) => !value)} sortAscending={sortAscending} />
    </section>
    {formOpen && currentUser.role === 'patient' && <Modal title="Request an appointment" onClose={() => { setFormOpen(false); setSearchParams({}) }}>
      <p className="modal-description">Create a request preview using fictional demo data. This does not make or confirm a real appointment.</p>
      <form className="form-grid" onSubmit={createAppointment}>
        <label>Service<select name="service" required>{serviceChoices.map((item) => <option key={item}>{item}</option>)}</select></label>
        <label>Available doctor<select name="doctorId" required>{doctors.filter((item) => item.status === 'Active').map((item) => <option value={item.id} key={item.id}>{item.name} · {item.specialty}</option>)}</select></label>
        <label>Preferred date<input type="date" name="date" min={todayIso} required /></label>
        <label>Preferred time<input type="time" name="time" required /></label>
        <div className="form-actions"><button type="button" className="button button-secondary" onClick={() => setFormOpen(false)}>Cancel</button><button className="button button-primary" type="submit"><CalendarDays size={16} /> Preview request</button></div>
      </form>
    </Modal>}
  </div>
}

function AppointmentsTable({ appointments, loading, compact = false, showActions = false, onStatusChange, onSort, sortAscending = true }: {
  appointments: Appointment[]
  loading: boolean
  compact?: boolean
  showActions?: boolean
  onStatusChange?: (id: string, status: AppointmentStatus) => void
  onSort?: () => void
  sortAscending?: boolean
}) {
  if (loading) return <div className="loading-state">Loading sample appointments...</div>
  if (!appointments.length) return <EmptyState title="No appointments found" detail="Try a different filter or create a request to see it here." />
  return <div className={`table-wrap ${compact ? 'compact-table-wrap' : ''}`}><table className="data-table"><thead><tr>
    <th>{onSort ? <button className="sort-button" onClick={onSort}>Date & time {sortAscending ? <ArrowUp size={13} /> : <ArrowDown size={13} />}</button> : 'Date & time'}</th>
    <th>{compact ? 'Patient / doctor' : 'Patient'}</th><th>Service</th><th>Status</th>{showActions && <th>Update status</th>}
  </tr></thead><tbody>{appointments.map((item) => <tr key={item.id}>
    <td><strong>{prettyDate(item.date)}</strong><small>{item.time}</small></td>
    <td><strong>{item.patientName}</strong><small>{item.doctorName}</small></td><td>{item.service}</td><td><StatusBadge status={item.status} /></td>
    {showActions && <td><select className="row-select" aria-label={`Update ${item.patientName} appointment status`} value={item.status} onChange={(event) => onStatusChange?.(item.id, event.target.value as AppointmentStatus)}>{(['Requested', 'Confirmed', 'Completed', 'Cancelled'] as AppointmentStatus[]).map((value) => <option key={value}>{value}</option>)}</select></td>}
  </tr>)}</tbody></table></div>
}

function Modal({ title, children, onClose }: { title: string; children: ReactNode; onClose: () => void }) {
  const modalRef = useRef<HTMLElement>(null)
  useEffect(() => {
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null
    const focusable = () => modalRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href]')
    focusable()?.[0]?.focus()
    const closeOnKeyboard = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
      if (event.key === 'Tab') {
        const controls = focusable()
        if (!controls?.length) return
        const first = controls[0]
        const last = controls[controls.length - 1]
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus() }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus() }
      }
    }
    window.addEventListener('keydown', closeOnKeyboard)
    return () => { window.removeEventListener('keydown', closeOnKeyboard); previouslyFocused?.focus() }
  }, [onClose])
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title" ref={modalRef}><div className="modal-heading"><h2 id="modal-title">{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={19} /></button></div>{children}</section></div>
}

export function ManagementPage({ section, allowedRoles }: { section: 'patients' | 'doctors' | 'services' | 'schedule' | 'reports' | 'settings'; allowedRoles: Role[] }) {
  const { user } = useAuth()
  const [query, setQuery] = useState('')
  const [patients, setPatients] = useState<Patient[]>(demoPatients)
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [serviceCatalog, setServiceCatalog] = useState<string[]>(services)
  const [serviceEditorOpen, setServiceEditorOpen] = useState(false)
  const [addOpen, setAddOpen] = useState(false)
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null)
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)
  const [message, setMessage] = useState('')
  const [managementError, setManagementError] = useState('')
  const [availability, setAvailability] = useState<Record<string, boolean>>({ Monday: true, Tuesday: true, Wednesday: true, Thursday: true, Friday: true, Saturday: false, Sunday: false })

  useEffect(() => {
    if (section !== 'doctors' && section !== 'patients' && section !== 'services') return
    let active = true
    const reportError = (cause: unknown) => {
      if (active) setManagementError(cause instanceof Error ? cause.message : 'Could not load sample directory data. Please try again.')
    }
    if (section === 'doctors') clinicApi.getDoctors().then((rows) => { if (active) setDoctors(rows) }).catch(reportError)
    if (section === 'patients') clinicApi.getPatients().then((rows) => { if (active) setPatients(rows) }).catch(reportError)
    if (section === 'services') clinicApi.getServices().then((rows) => { if (active) setServiceCatalog(rows) }).catch(reportError)
    return () => { active = false }
  }, [section])

  if (!user || !allowedRoles.includes(user.role)) return <Navigate to={user ? `/${user.role}` : '/login'} replace />
  if (section === 'patients') {
    const results = patients.filter((patient) => `${patient.name} ${patient.email} ${patient.phone}`.toLowerCase().includes(query.toLowerCase()))
    async function savePatient(event: FormEvent<HTMLFormElement>) {
      event.preventDefault()
      if (!selectedPatient) return
      const form = new FormData(event.currentTarget)
      try {
        const updated = await clinicApi.updatePatient(selectedPatient.id, {
          name: String(form.get('name')), email: String(form.get('email')), phone: String(form.get('phone')),
          lastVisit: selectedPatient.lastVisit, status: String(form.get('status')) as Patient['status'],
        })
        setPatients((items) => items.map((patient) => patient.id === updated.id ? updated : patient))
        setSelectedPatient(null)
        setMessage('Sample patient profile updated for this session only.')
        setManagementError('')
      } catch (cause) {
        setManagementError(cause instanceof Error ? cause.message : 'Could not update the sample profile. Please try again.')
      }
    }
    return <div className="page-stack">
      <PageHeading eyebrow="CARE DIRECTORY" title="Patients" subtitle="Fictional sample profiles for the clinical workspace." />
      <p className="demo-banner"><Users size={17} /><span><strong>Sample patient information</strong> This directory is illustrative only. Patient access and record permissions must be enforced by the backend.</span></p>
      {message && <div className="form-message success-message" role="status">{message}<button aria-label="Dismiss message" onClick={() => setMessage('')}><X size={15} /></button></div>}
      {managementError && <div className="form-message error-message" role="alert">{managementError}<button aria-label="Dismiss error" onClick={() => setManagementError('')}><X size={15} /></button></div>}
      <section className="surface-card table-card">
        <div className="table-toolbar"><div className="table-toolbar-title"><h2>Patient directory</h2><span>{results.length} records</span></div><SearchFilter value={query} onChange={setQuery} /></div>
        <div className="table-wrap"><table className="data-table"><thead><tr><th>Patient</th><th>Contact</th><th>Last visit</th><th>Care status</th><th>Access</th></tr></thead><tbody>{results.map((patient) => <tr key={patient.id}>
          <td><strong>{patient.name}</strong><small>Sample ID · {patient.id}</small></td><td>{patient.email}<small>{patient.phone}</small></td><td>{prettyDate(patient.lastVisit)}</td><td><StatusBadge status={patient.status} /></td>
          <td><button className="button button-secondary button-small" onClick={() => setSelectedPatient(patient)}>{user.role === 'admin' ? 'Edit profile' : 'View profile'}</button></td>
        </tr>)}</tbody></table>{results.length === 0 && <EmptyState title="No matching patients" detail="Try another name or email." />}</div>
      </section>
      {selectedPatient && user.role === 'admin' && <Modal title="Edit sample patient profile" onClose={() => setSelectedPatient(null)}>
        <p className="modal-description">Updates apply only to this in-memory demo directory.</p>
        <form className="form-grid" onSubmit={savePatient}>
          <label>Full name<input name="name" defaultValue={selectedPatient.name} required /></label>
          <label>Email address<input name="email" type="email" defaultValue={selectedPatient.email} required /></label>
          <label>Phone number<input name="phone" defaultValue={selectedPatient.phone} required /></label>
          <label>Care status<select name="status" defaultValue={selectedPatient.status}><option>Active</option><option>Follow-up</option></select></label>
          <div className="form-actions"><button type="button" className="button button-secondary" onClick={() => setSelectedPatient(null)}>Cancel</button><button className="button button-primary" type="submit">Save profile preview</button></div>
        </form>
      </Modal>}
      {selectedPatient && user.role !== 'admin' && <Modal title="Sample patient profile" onClose={() => setSelectedPatient(null)}>
        <div className="patient-detail">
          <div className="profile-summary"><span className="avatar avatar-large">{selectedPatient.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><div><h2>{selectedPatient.name}</h2><p>Fictional patient · {selectedPatient.id}</p><StatusBadge status={selectedPatient.status} /></div></div>
          <dl><div><dt>Email</dt><dd>{selectedPatient.email}</dd></div><div><dt>Phone</dt><dd>{selectedPatient.phone}</dd></div><div><dt>Last sample visit</dt><dd>{prettyDate(selectedPatient.lastVisit)}</dd></div></dl>
          <p className="panel-footnote">Clinical records are not assigned to this profile in the demo. Connect the backend patient API and enforce record-level permissions before showing real clinical data.</p>
        </div>
      </Modal>}
    </div>
  }

  if (section === 'doctors') {
    const results = doctors.filter((doctor) => `${doctor.name} ${doctor.specialty} ${doctor.email}`.toLowerCase().includes(query.toLowerCase()))
    async function saveDoctor(event: FormEvent<HTMLFormElement>) {
      event.preventDefault()
      const form = new FormData(event.currentTarget)
      try {
        const values = { name: String(form.get('name')), specialty: String(form.get('specialty')), email: String(form.get('email')), status: editingDoctor?.status ?? 'Active' as Doctor['status'] }
        if (editingDoctor) {
          const updated = await clinicApi.updateDoctor(editingDoctor.id, values)
          setDoctors((items) => items.map((doctor) => doctor.id === updated.id ? updated : doctor))
        } else {
          const added = await clinicApi.addDoctor(values)
          setDoctors((items) => [added, ...items])
        }
        setAddOpen(false)
        setMessage(editingDoctor ? 'Sample doctor profile updated for this session only.' : 'Sample doctor added to this session only.')
        setManagementError('')
        setEditingDoctor(null)
      } catch (cause) {
        setManagementError(cause instanceof Error ? cause.message : 'Could not save this doctor. Please try again.')
      }
    }
    async function toggleDoctor(doctor: Doctor) {
      const status = doctor.status === 'Active' ? 'On leave' : 'Active'
      if (!window.confirm(`Set ${doctor.name} to ${status.toLowerCase()} in this demo?`)) return
      try {
        await clinicApi.updateDoctorStatus(doctor.id, status)
        setDoctors(await clinicApi.getDoctors())
        setMessage('Doctor status updated in this demo session.')
        setManagementError('')
      } catch (cause) {
        setManagementError(cause instanceof Error ? cause.message : 'Could not update provider status. Please try again.')
      }
    }
    return <div className="page-stack"><PageHeading eyebrow="CLINIC DIRECTORY" title="Doctors" subtitle="Manage sample provider profiles and availability." action={<button className="button button-primary" onClick={() => { setEditingDoctor(null); setAddOpen(true) }}><Plus size={17} /> Add doctor</button>} /><p className="demo-banner"><Stethoscope size={17} /><span><strong>Demo management</strong> Changes are temporary and do not update a real clinic directory.</span></p>{message && <div className="form-message success-message" role="status">{message}<button aria-label="Dismiss message" onClick={() => setMessage('')}><X size={15} /></button></div>}{managementError && <div className="form-message error-message" role="alert">{managementError}<button aria-label="Dismiss error" onClick={() => setManagementError('')}><X size={15} /></button></div>}<section className="surface-card table-card"><div className="table-toolbar"><div className="table-toolbar-title"><h2>Care team</h2><span>{results.length} providers</span></div><SearchFilter value={query} onChange={setQuery} /></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Provider</th><th>Specialty</th><th>Email</th><th>Status</th><th>Manage</th></tr></thead><tbody>{results.map((doctor) => <tr key={doctor.id}><td><strong>{doctor.name}</strong><small>Sample provider</small></td><td>{doctor.specialty}</td><td>{doctor.email}</td><td><StatusBadge status={doctor.status} /></td><td><div className="table-actions"><button className="button button-secondary button-small" onClick={() => { setEditingDoctor(doctor); setAddOpen(true) }}><Pencil size={13} /> Edit</button><button className="button button-secondary button-small" onClick={() => void toggleDoctor(doctor)}>{doctor.status === 'Active' ? 'Set on leave' : 'Reactivate'}</button></div></td></tr>)}</tbody></table>{results.length === 0 && <EmptyState title="No matching doctors" detail="Try a different search." />}</div></section>{addOpen && <Modal title={editingDoctor ? 'Edit sample doctor' : 'Add a sample doctor'} onClose={() => { setAddOpen(false); setEditingDoctor(null) }}><p className="modal-description">This profile exists only in the current demo session.</p><form className="form-grid" onSubmit={saveDoctor}><label>Full name<input name="name" defaultValue={editingDoctor?.name} required /></label><label>Specialty<select name="specialty" defaultValue={editingDoctor?.specialty ?? services[0]}>{services.map((service) => <option key={service}>{service}</option>)}</select></label><label className="full-width">Email address<input name="email" type="email" defaultValue={editingDoctor?.email} required /></label><div className="form-actions"><button className="button button-secondary" type="button" onClick={() => { setAddOpen(false); setEditingDoctor(null) }}>Cancel</button><button className="button button-primary" type="submit">{editingDoctor ? 'Save changes' : 'Add sample doctor'}</button></div></form></Modal>}</div>
  }

  if (section === 'services') {
    async function createService(event: FormEvent<HTMLFormElement>) {
      event.preventDefault()
      const form = new FormData(event.currentTarget)
      try {
        setServiceCatalog(await clinicApi.addService(String(form.get('name'))))
        setServiceEditorOpen(false)
        setMessage('Sample service added for this session only.')
      } catch (cause) {
        setManagementError(cause instanceof Error ? cause.message : 'Unable to add service. Please try again.')
      }
    }
    async function removeService(service: string) {
      if (!window.confirm(`Remove ${service} from the demo service catalog?`)) return
      setServiceCatalog(await clinicApi.deleteService(service))
      setMessage('Sample service removed for this session only.')
    }
    return <div className="page-stack">
      <PageHeading eyebrow="CARE CATALOG" title="Services" subtitle="Manage the sample clinic service catalog." action={<button className="button button-primary" onClick={() => setServiceEditorOpen(true)}><Plus size={17} /> Add service</button>} />
      <p className="demo-banner"><Activity size={17} /><span><strong>Illustrative services</strong> These services are based on the existing OpenClinic demo content and may not reflect a real clinic's offerings.</span></p>
      {message && <div className="form-message success-message" role="status">{message}<button aria-label="Dismiss message" onClick={() => setMessage('')}><X size={15} /></button></div>}
      {managementError && <div className="form-message error-message" role="alert">{managementError}<button aria-label="Dismiss error" onClick={() => setManagementError('')}><X size={15} /></button></div>}
      <div className="service-grid">{serviceCatalog.map((service, index) => <article className="surface-card service-card" key={service}>
        <span className="service-icon">{index % 2 ? <Activity size={20} /> : <Stethoscope size={20} />}</span><span className="eyebrow">CARE SERVICE</span><h2>{service}</h2>
        <p>Sample service information for demonstration. Confirm real services and availability with the clinic.</p>
        <div className="service-management"><span className="service-open">Available to request <CheckCircle2 size={15} /></span><button className="text-button" onClick={() => void removeService(service)}>Remove</button></div>
      </article>)}</div>
      {serviceEditorOpen && <Modal title="Add a sample service" onClose={() => setServiceEditorOpen(false)}><p className="modal-description">New catalog items are temporary and can be selected in appointment request previews.</p><form className="form-grid" onSubmit={createService}><label className="full-width">Service name<input name="name" required maxLength={60} /></label><div className="form-actions"><button type="button" className="button button-secondary" onClick={() => setServiceEditorOpen(false)}>Cancel</button><button className="button button-primary" type="submit">Add service</button></div></form></Modal>}
    </div>
  }

  if (section === 'schedule') return <div className="page-stack"><PageHeading eyebrow="DOCTOR WORKSPACE" title="My schedule" subtitle="Set your sample availability for a schedule preview." /><p className="demo-banner"><Clock3 size={17} /><span><strong>Schedule demo</strong> Availability is stored only in this page during your current visit and is not shared with patients.</span></p><section className="surface-card schedule-card"><div className="card-heading"><div><h2>Weekly availability</h2><p>Turn demo availability on or off for each day.</p></div><Clock3 size={20} className="heading-icon" /></div>{Object.entries(availability).map(([day, enabled]) => <label className="availability-row" key={day}><span><strong>{day}</strong><small>{enabled ? 'Available for sample appointments' : 'Unavailable'}</small></span><input type="checkbox" checked={enabled} onChange={() => setAvailability((current) => ({ ...current, [day]: !current[day] }))} aria-label={`${day} availability`} /></label>)}<p className="panel-footnote">No appointment time slots are published by this frontend demonstration.</p></section></div>

  if (section === 'reports') return <ReportsPage />

  return <SettingsPage />
}

function SearchFilter({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return <label className="table-search"><Search size={16} /><input value={value} onChange={(event) => onChange(event.target.value)} placeholder="Search directory" aria-label="Search directory" /></label>
}

function ReportsPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([])
  useEffect(() => { clinicApi.getAppointments().then(setAppointments) }, [])
  const metrics = [
    { label: 'Total appointments', value: appointments.length, icon: CalendarDays },
    { label: 'Confirmed visits', value: appointments.filter((item) => item.status === 'Confirmed').length, icon: CheckCircle2 },
    { label: 'Sample providers', value: 6, icon: Stethoscope },
    { label: 'Sample patients', value: demoPatients.length, icon: Users },
  ]
  return <div className="page-stack"><PageHeading eyebrow="CLINIC INSIGHTS" title="Reports" subtitle="A small overview built from fictional data in this demo session." /><p className="demo-banner"><Activity size={17} /><span><strong>Not operational reporting</strong> These sample metrics are not connected to real clinic activity and should not be used for decisions.</span></p><div className="stats-grid">{metrics.map((metric) => <StatCard key={metric.label} {...metric} detail="Illustrative demo data" />)}</div><section className="surface-card report-note"><div className="report-note-icon"><FileText size={20} /></div><div><h2>Reporting is not connected</h2><p>Live reporting, exports, and analytics will need to be implemented with the backend API and authorized data.</p></div></section></div>
}

function SettingsPage() {
  const [saved, setSaved] = useState(false)
  const [digest, setDigest] = useState(false)
  return <div className="page-stack"><PageHeading eyebrow="ADMINISTRATION" title="System settings" subtitle="Frontend demonstration preferences." /><p className="demo-banner"><Activity size={17} /><span><strong>Local-only settings</strong> These controls demonstrate the interface; they do not configure a real clinic system.</span></p><section className="surface-card settings-card"><div className="card-heading"><div><h2>Workspace preferences</h2><p>Example settings for this browser session.</p></div></div><label className="availability-row"><span><strong>Appointment reminder digest</strong><small>Show an example weekly reminder preference</small></span><input type="checkbox" checked={digest} onChange={(event) => { setDigest(event.target.checked); setSaved(false) }} /></label><label className="availability-row"><span><strong>Demo data mode</strong><small>Always enabled until backend integration</small></span><input type="checkbox" checked disabled aria-label="Demo data mode is always enabled" /></label><div className="form-actions"><button className="button button-primary" onClick={() => setSaved(true)}>Save preference preview</button>{saved && <span className="settings-saved"><Check size={16} /> Preference preview saved for this session</span>}</div></section></div>
}

export function ProfilePage() {
  const { user } = useAuth()
  const [name, setName] = useState(user?.name ?? '')
  const [phone, setPhone] = useState(user?.phone ?? '')
  const [saved, setSaved] = useState(false)
  if (!user) return null
  function save(event: FormEvent<HTMLFormElement>) { event.preventDefault(); setSaved(true) }
  return <div className="page-stack"><PageHeading eyebrow="ACCOUNT" title="My profile" subtitle="Review your demo profile and personal preferences." /><p className="demo-banner"><Activity size={17} /><span><strong>Profile preview</strong> Changes are kept in this page only. Account records are not updated or sent anywhere.</span></p><section className="surface-card profile-card"><div className="profile-summary"><span className="avatar avatar-large">{user.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><div><h2>{user.name}</h2><p>{user.title ?? user.role} <span>·</span> Demo account</p><span className="status-badge status-active"><span /> Demo profile</span></div></div><form className="form-grid profile-form" onSubmit={save}><label>Display name<input value={name} onChange={(event) => { setName(event.target.value); setSaved(false) }} required /></label><label>Email address<input value={user.email} disabled /></label><label>Phone number<input type="tel" value={phone} onChange={(event) => { setPhone(event.target.value); setSaved(false) }} placeholder="Add a demo phone number" /></label><label>Workspace role<input value={user.role.charAt(0).toUpperCase() + user.role.slice(1)} disabled /></label><div className="full-width form-actions"><button className="button button-primary" type="submit">Save profile preview</button>{saved && <span className="settings-saved"><Check size={16} /> Profile preview updated in this page</span>}</div></form></section></div>
}

export function RecordsPage() {
  const { user } = useAuth()
  if (user?.role !== 'patient') return <Navigate to={`/${user?.role ?? 'login'}`} replace />
  return <div className="page-stack"><PageHeading eyebrow="PATIENT PORTAL" title="Medical records" subtitle="A sample records view showing how clinical documents may appear." /><p className="demo-banner"><FileText size={17} /><span><strong>Fictional mock records only</strong> No real medical records or prescriptions are connected, stored, or available in this demo.</span></p><section className="surface-card table-card"><div className="table-toolbar"><div className="table-toolbar-title"><h2>Documents</h2><span>{demoRecords.length} sample records</span></div></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Date</th><th>Record type</th><th>Details</th><th>Provider</th><th>Preview</th></tr></thead><tbody>{demoRecords.map((record) => <tr key={record.date}><td>{prettyDate(record.date)}</td><td><strong>{record.type}</strong></td><td>{record.detail}</td><td>{record.provider}</td><td><button className="button button-secondary button-small" onClick={() => window.alert('This is a fictional sample record. Document previews require a connected clinical records backend.')}>View sample</button></td></tr>)}</tbody></table></div></section><p className="records-disclaimer">Never use this demonstration for real patient information or care decisions.</p></div>
}

export function NotFoundPage() {
  const { user } = useAuth()
  return <div className="not-found"><span className="not-found-code">404</span><h1>Page not found</h1><p>This workspace page doesn't exist or may have moved.</p><Link to={`/${user?.role ?? 'login'}`} className="button button-primary">Return to dashboard <ArrowRight size={16} /></Link></div>
}
