import { demoAppointments, demoDoctors, demoPatients } from '../data/demoData'
import { services as demoServices } from '../data/demoData'
import type { Appointment, AppointmentStatus, AuthUser, Doctor, Patient, PatientRegistration } from '../types'

let appointments = [...demoAppointments]
let doctors = [...demoDoctors]
let patients = [...demoPatients]
let serviceCatalog = [...demoServices]
const registeredPatients: AuthUser[] = []

function normalizePhone(phone: string) {
  return phone.replace(/\D/g, '')
}

export const clinicApi = {
  async demoSignIn(email: string, role: AuthUser['role']): Promise<AuthUser> {
    const normalizedEmail = email.trim().toLowerCase()
    if (!normalizedEmail.includes('@')) throw new Error('Enter a valid email address.')
    const names: Record<AuthUser['role'], string> = {
      patient: 'Aarav Shah',
      doctor: 'Dr. Ananya Mehta',
      admin: 'Clinic Administrator',
    }
    const ids: Record<AuthUser['role'], string> = { patient: 'pat-1', doctor: 'doc-1', admin: 'admin-demo' }
    return { id: ids[role], name: names[role], email: normalizedEmail, role, title: role === 'doctor' ? 'General Physician' : undefined }
  },

  async registerPatient(input: PatientRegistration): Promise<AuthUser> {
    const name = input.name.trim()
    const email = input.email.trim().toLowerCase()
    const phone = input.phone.trim()
    const normalizedPhone = normalizePhone(phone)
    if (!name || !email.includes('@') || normalizedPhone.length < 7) {
      throw new Error('Enter your name, a valid email address, and a phone number with at least 7 digits.')
    }
    if (registeredPatients.some((patient) =>
      patient.email === email || normalizePhone(patient.phone ?? '') === normalizedPhone,
    )) {
      throw new Error('An account with this email address or phone number already exists.')
    }
    const patient: AuthUser = {
      id: `patient-${crypto.randomUUID()}`,
      name,
      email,
      phone,
      role: 'patient',
    }
    registeredPatients.push(patient)
    return patient
  },

  async signInPatient(name: string, phone: string, email: string): Promise<AuthUser> {
    const normalizedName = name.trim().toLowerCase()
    const normalizedPhone = normalizePhone(phone)
    const normalizedEmail = email.trim().toLowerCase()
    const patient = registeredPatients.find((account) =>
      account.name.toLowerCase() === normalizedName
      && normalizePhone(account.phone ?? '') === normalizedPhone
      && account.email === normalizedEmail,
    )
    if (!patient) throw new Error('No matching patient account was found. Check your details or register first.')
    return patient
  },

  async getAppointments(): Promise<Appointment[]> {
    return [...appointments]
  },

  async createAppointment(input: Omit<Appointment, 'id' | 'status'>): Promise<Appointment> {
    const appointment: Appointment = { ...input, id: `apt-${Date.now()}`, status: 'Requested' }
    appointments = [appointment, ...appointments]
    return appointment
  },

  async updateAppointmentStatus(id: string, status: AppointmentStatus): Promise<void> {
    appointments = appointments.map((appointment) => appointment.id === id ? { ...appointment, status } : appointment)
  },

  async getDoctors(): Promise<Doctor[]> {
    return [...doctors]
  },

  async getServices(): Promise<string[]> {
    return [...serviceCatalog]
  },

  async addService(service: string): Promise<string[]> {
    const normalized = service.trim()
    if (!normalized || serviceCatalog.some((item) => item.toLowerCase() === normalized.toLowerCase())) {
      throw new Error('Enter a unique service name.')
    }
    serviceCatalog = [...serviceCatalog, normalized]
    return [...serviceCatalog]
  },

  async deleteService(service: string): Promise<string[]> {
    serviceCatalog = serviceCatalog.filter((item) => item !== service)
    return [...serviceCatalog]
  },

  async updateDoctor(id: string, values: Omit<Doctor, 'id'>): Promise<Doctor> {
    const updated = { ...values, id }
    doctors = doctors.map((doctor) => doctor.id === id ? updated : doctor)
    return updated
  },

  async updateDoctorStatus(id: string, status: Doctor['status']): Promise<void> {
    doctors = doctors.map((doctor) => doctor.id === id ? { ...doctor, status } : doctor)
  },

  async addDoctor(doctor: Omit<Doctor, 'id'>): Promise<Doctor> {
    const addedDoctor = { ...doctor, id: `doc-${Date.now()}` }
    doctors = [addedDoctor, ...doctors]
    return addedDoctor
  },

  async getPatients() {
    return [...patients]
  },

  async updatePatient(id: string, values: Omit<Patient, 'id'>): Promise<Patient> {
    const updated = { ...values, id }
    patients = patients.map((patient) => patient.id === id ? updated : patient)
    return updated
  },
}
