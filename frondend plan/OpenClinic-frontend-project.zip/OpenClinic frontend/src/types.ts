export type Role = 'patient' | 'doctor' | 'admin'

export type AuthUser = {
  id: string
  name: string
  email: string
  phone?: string
  role: Role
  title?: string
}

export type PatientRegistration = Pick<AuthUser, 'name' | 'email'> & { phone: string }

export type AppointmentStatus = 'Requested' | 'Confirmed' | 'Completed' | 'Cancelled'

export type Appointment = {
  id: string
  patientId: string
  patientName: string
  doctorId: string
  doctorName: string
  service: string
  date: string
  time: string
  status: AppointmentStatus
  note?: string
}

export type Doctor = {
  id: string
  name: string
  specialty: string
  email: string
  status: 'Active' | 'On leave'
}

export type Patient = {
  id: string
  name: string
  email: string
  phone: string
  lastVisit: string
  status: 'Active' | 'Follow-up'
}
